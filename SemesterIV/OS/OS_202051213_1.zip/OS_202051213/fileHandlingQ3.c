#include<stdio.h>
#include<stdlib.h>

void main(){

    FILE *file1, *file2, *fileNew;
    char fname1[20], fname2[20], fnameNew[20];

    printf("Input the name of first file : ");
    scanf("%s", fname1);
    printf("Input the name of second file : ");
    scanf("%s", fname2);

    file1 = fopen(fname1, "r");
    file2 = fopen(fname2, "r");

    if(file1 == NULL || file2 == NULL){
        printf("Error occured");
        exit(1);
    }

    printf("Enter the name of the new file (in which both files will be merged) : ");
    scanf("%s", fnameNew);

    fileNew = fopen(fnameNew, "w");

    if(fileNew == NULL){
        printf("File not created or error in opening.");
        exit(1);
    } else {
        printf("File %s created successfully.\n", fnameNew);
    }

    //reading the contents from file1 and writing it in fileNew
    char ch;
    while((ch = fgetc(file1)) != EOF){
        fputc(ch, fileNew);
    }
    
    //reading the contents from file2 and writing it in fileNew
    while((ch = fgetc(file2)) != EOF){
        fputc(ch, fileNew);
    }

    printf("Files %s and %s merged successfully to file %s.", fname1, fname2, fnameNew);

}