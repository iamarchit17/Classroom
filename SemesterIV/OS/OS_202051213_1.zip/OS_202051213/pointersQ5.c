#include<Stdio.h>

int stringLength(char str[]){
    int i = 0;
    while(*(str + i) != '\0'){
        i++;
    }

    return i - 1;
}

void main(){
    char str[1000];
    printf("Enter a string : ");
    fgets(str, sizeof str, stdin);
    printf("Length of string is %d", stringLength(str));
}