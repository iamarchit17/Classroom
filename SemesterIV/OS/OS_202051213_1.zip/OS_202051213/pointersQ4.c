#include<Stdio.h>

void main(){
    int n;
    printf("Enter the size of array : ");
    scanf("%d", &n);
    int arr[n];
    int *p = arr;
    printf("Enter the array elements : ");
    for(int i = 0; i < n; i++){
        scanf("%d", p + i);
    }
    
    for(int i = 0; i < n; i++){
        printf("array[%d] = %d\n", i, *(p + i));
    }
}