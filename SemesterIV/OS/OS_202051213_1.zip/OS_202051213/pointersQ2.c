#include<stdio.h>

int addUsingPointers(int *a, int *b){
    return *a + *b;
}

void main(){

    int i;
    int j;
    int *addrI = &i;
    int *addrJ = &j;
    printf("Enter two numbers : ");
    scanf("%d", addrI);
    scanf("%d", addrJ);

    printf("i = %d, j = %d, i + j = %d", *addrI, *addrJ, addUsingPointers(addrI, addrJ));
}