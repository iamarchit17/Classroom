#include<stdio.h>

void main(){
    //Write a program to display address of an integer variable, character variable and string variable using pointers
    int i = 10;
    char c = 'B';
    char str[] = "Archit";

    int *addressInt = &i;
    char *addressChar = &c;
    char *addressStr = str; //since sting name 'str' is the address of 0th index of string

    printf("Address of Integer Variable   : %p\n", addressInt);
    printf("Address of Character Variable : %p\n", addressChar);
    printf("Address of String Variable    : %p\n", addressStr);

}

