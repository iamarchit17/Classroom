#include<stdio.h>
#include<stdlib.h>

void main(){

    FILE *fptr;
    char fname[20];
    printf("Input the file name to be opened : ");
    scanf("%s", fname);

    fptr = fopen(fname, "r");

    int words = 1;
    int characters = 1;

    if(fptr == NULL){
        printf("Error! File not opened."); 
    } else {
        char ch = fgetc(fptr);
        printf("The content in the file %s is:\n\n", fname);

        while(ch!=EOF) { 
            printf("%c",ch); 
            if(ch==' '||ch=='\n') words++; 
            else characters++;
            ch = fgetc(fptr); 
        }
    }

    printf("\nThe number of words in the file are      : %d", words - 2);
    printf("\nThe number of characters in the file are : %d", characters - 1);
}