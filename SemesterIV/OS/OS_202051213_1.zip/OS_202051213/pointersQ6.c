#include<stdio.h>

void bubbleSort(int n, int* ptr){
    int i, j;

    for (i = 0; i < n; i++){ 
        for (j = i + 1; j < n; j++){
            if (*(ptr + j) < *(ptr + i)){
                int temp = *(ptr + i);
                *(ptr + i) = *(ptr + j);
                *(ptr + j) = temp;
            }
        }
    }
}

void main(){
    int n;
    printf("Enter the size of array : ");
    scanf("%d", &n);
    int arr[n];
    int *p = arr;
    printf("Enter the array elements : ");
    for(int i = 0; i < n; i++){
        scanf("%d", p + i);
    }


    bubbleSort(n, arr);
    printf("Sorted Array : ");

    for(int i = 0; i < n; i++){
        printf("%d ", *(p + i));
    }
}