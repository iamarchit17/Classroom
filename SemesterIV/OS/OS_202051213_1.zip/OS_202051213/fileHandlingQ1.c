#include<stdio.h>
#include<stdlib.h>

void main(){
    
    FILE *fptr;
    char fname[] = "question1.txt";

    fptr = fopen(fname, "w");
    if(fptr == NULL){
        printf("File not created");
        exit(1);
    } else {
        printf("File created successfully");
    }
    printf("\nEnter a string to write in the created 'question1.txt' file : ");
    char str[500];
    fgets(str, sizeof str, stdin);
    fputs(str, fptr);
    fclose(fptr);

}