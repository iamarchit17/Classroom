#include<stdio.h>

int max(int *a, int *b){
    return *a > *b ? *a : *b;
}

void main(){
    int i;
    int j;
    int *addrI = &i;
    int *addrJ = &j;

    printf("Enter two numbers : ");
    scanf("%d", addrI);
    scanf("%d", addrJ);
    
    printf("i = %d, j = %d, maximum of i and j = %d", *addrI, *addrJ, max(addrI, addrJ));
}


