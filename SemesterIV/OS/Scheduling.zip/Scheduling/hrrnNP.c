/*
Name: Archit Agrawal
Student ID: 202051213

The following code is a simulation of the  Non-Preemptive Highest Resoponse Ratio Next Scheduling
Documentation:
The matrix mat stores all the data of the processes in the following code
    At index 0 -> Process ID
    At index 1 -> Arrival Time
    At index 2 -> Burst Time
    At index 3 -> finish or completion time
    At index 4 -> turn around time
    At index 5 -> waiting time

*/


#include<stdio.h>

//function to arrange processes by their arrival times
void arrangeArrival(int num, int mat[][6]);
//function to calculate completion time for each process
void completionTime(int num, int mat[][6]);
//function to calculate TAT for each process
void turnAroundTime(int num, int mat[][6]);
//function to calculate WT for each process
void waitingTime(int num, int mat[][6]);
//function to calculate average TAT
double avgTAT(int num, int mat[][6]);
//function to calculate average WT
double avgWT(int num, int mat[][6]);
//scheduling function that the user need to call
void HRRNScheduling(int num, int mat[][6]);

//utility function to print the result in formatted way
void printResult(int num, int mat[][6]);

void arrangeArrival(int num, int mat[][6]){
    for (int i = 0; i < num; i++) {
        for (int j = 0; j < num - i - 1; j++) {
            if (mat[j][1] > mat[j + 1][1]) {
                for (int k = 0; k < 3; k++) {
                    
                    int temp = mat[j][k];
                    mat[j][k] = mat[j + 1][k];
                    mat[j + 1][k] = temp;
                }
            }
        }
    }

}

void completionTime(int num, int mat[][6]){
    int arr[num];
    for(int i = 0; i < num; i++) arr[i] = 0;
    int j = 0;
    int currTime = mat[0][1];
    int completed = 0;

    double hrrn[num];
    for(int i = 0; i < num; i++) hrrn[i] = 0.0;

    while(completed != num){
        while(j < num && arr[j] != -1 && mat[j][1] <= currTime){
            arr[j] = 1;
            j++;
        }

        for(int k = 0; k < num; k++){
            if(arr[k] == 1){
                hrrn[k] = 1.0 + (double)(currTime - mat[k][1])/mat[k][2];
            }
        }

        //for(int s = 0; s <num; s++) printf("%d, ", arr[s]);
        //printf("currTime : %d, j = %d, completed = %d\n", currTime, j, completed);

        int currProc = 0;
        for(int k = 0; k < num; k++){
            if(arr[k] == 1){
                currProc = k;
                break;
            }
        }

        for(int k = currProc + 1; k < num; k++){
            if(arr[k] == 1 && hrrn[k] > hrrn[currProc]){
                currProc = k;
            }
        }

        currTime += mat[currProc][2];
        mat[currProc][3] = currTime;
        completed++;
        arr[currProc] = -1;
        hrrn[currProc] = -1.0;
        
        //printf("currTime : %d, j = %d, completed = %d\n", currTime, j, completed);
        if(j < num && j - completed < 1 && mat[j][1] > currTime){
            currTime = mat[j][1];
        }
    
        
    }
    //printf("Completion Time Done");
    turnAroundTime(num, mat);
    //printf("TAT Done");
    waitingTime(num, mat);
    //printf("WT Done");
    printResult(num, mat);
}

void turnAroundTime(int num, int mat[][6]){
    for(int i = 0; i < num; i++) mat[i][4] = mat[i][3] - mat[i][1];
}

void waitingTime(int num, int mat[][6]){
    for(int i = 0; i < num; i++) mat[i][5] = mat[i][4] - mat[i][2];
}

double avgTAT(int num, int mat[][6]){
    int sum = 0;
    for(int i = 0; i < num; i++) sum += mat[i][4];
    return (double)sum/num;
}

double avgWT(int num, int mat[][6]){
    int sum = 0;
    for(int i = 0; i < num; i++) sum += mat[i][5];
    return (double)sum/num;
}

void HRRNScheduling(int num, int mat[][6]){
    arrangeArrival(num, mat);
    completionTime(num, mat);
}

void printResult(int num, int mat[][6]){
    printf("\t\t\tNon-Preemptive Highest Response Ratio Next Scheduling\n");
    printf("Process ID \t Arrival Time \t Burst Time \t Completion Time \t Turn Around Time \t Waiting Time\n");
    for(int i = 0; i < num; i++){
        printf("    %d\t\t\t%d\t     %d   \t\t%d\t\t\t%d\t\t     %d\n", mat[i][0], mat[i][1], mat[i][2], mat[i][3], mat[i][4], mat[i][5]);
    }

    printf("Average Turn Around Time : %f\n", avgTAT(num, mat));
    printf("Average Wait Time : %f\n", avgWT(num, mat));
}

int main(){
    printf("**********Non-Preemptive Highest Response Ratio Next Scheduling**********\n");
    int n;
    printf("Enter the number of processes : ");
    scanf("%d", &n);
    int mat[n][6];

    printf("Enter 0 to put custom process ID's or -1 to give default 1 to N as process ID's : ");
    int id;
    scanf("%d", &id);

    if(id == -1){
        for(int i = 0; i < n; i++) mat[i][0] = i + 1;
    } else {
        printf("Enter Process ID's(separated by spaces) : ");
        for(int i = 0; i < n; i++){
            int s;
            scanf("%d", &s);
            mat[i][0] = s;
        }
    }

    printf("Enter Arrival Times(separated by spaces) : ");

    for(int i = 0; i < n; i++){
        int s;
        scanf("%d", &s);
        mat[i][1] = s;
    }

    printf("Enter Burst Times(separated by spaces) : ");

    for(int i = 0; i < n; i++){
        int s;
        scanf("%d", &s);
        mat[i][2] = s;
    }

    HRRNScheduling(n, mat);
}