/*
Name: Archit Agrawal
Student ID: 202051213

The following code is a simulation of the Multilevel Feedback Queue Scheduling.
In this scheduling, Queue 1 has Round-Robin Scheduling(quantum = quantumQ1),
Queue has Round-Robin Scheduling(quantum = quantumQ2) and
Queue 3 has First Come First Serve.

The matrix mat stores all the data of the processes in the following code
    At index 0 -> Process ID
    At index 1 -> Arrival Time
    At index 2 -> Burst Time
    At index 3 -> Priority (the lower the number, the higher the priority)
    At index 4 -> finish or completion time
    At index 5 -> turn around time
    At index 6 -> waiting time

*/
import java.util.*;

public class MFQS{

    public static void arrangeArrival(int num, int[][] mat){
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < num - i - 1; j++) {
                if (mat[j][1] > mat[j + 1][1]) {
                    for (int k = 0; k < 3; k++) {
                        int temp = mat[j][k];
                        mat[j][k] = mat[j + 1][k];
                        mat[j + 1][k] = temp;
                    }
                }
            }
        }
    }

    public static void completionTime(int num, int[][] mat, int quantumQ1, int quantumQ2){
        Queue<Integer> q1 = new PriorityQueue<>();
        Queue<Integer> q2 = new PriorityQueue<>();
        Queue<Integer> q3 = new PriorityQueue<>();

        int[] rem = new int[num];
        for(int i = 0; i < num; i++) rem[i] = mat[i][2];

        int currTime = mat[0][1];
        int j = 0;
        int completed = 0;

        while(completed != num){

            while(j < num && mat[j][1] <= currTime){
                q1.add(j);
                mat[j][5] = 0;
                j++;
            }

            if(q1.peek() != null){

                if(rem[q1.peek()] <= quantumQ1){
                    currTime += rem[q1.peek()];
                    rem[q1.peek()] = -1;
                    completed++;
                    mat[q1.peek()][3] = currTime;
                    q1.poll();
                } else {
                    rem[q1.peek()] = rem[q1.peek()] - quantumQ1;
                    currTime += quantumQ1;
                    q2.add(q1.poll());
                }

            } else if(q1.peek() == null && q2.peek() != null){

                if(j < num && mat[j][1] - currTime >= quantumQ2){
                    if(rem[q2.peek()] <= quantumQ2){
                        currTime += rem[q2.peek()];
                        rem[q2.peek()] = -1;
                        completed++;
                        mat[q2.peek()][3] = currTime;
                        q2.poll();
                    } else {
                        rem[q2.peek()] = rem[q2.peek()] - quantumQ2;
                        currTime += quantumQ2;
                        q3.add(q2.poll());                   
                    }
                } else if(j < num && mat[j][1] - currTime < quantumQ2){
                    if(rem[q2.peek()] <= mat[j][1] - currTime){
                        currTime += rem[q2.peek()];
                        rem[q2.peek()] = -1;
                        completed++;
                        mat[q2.peek()][3] = currTime;
                        q2.poll();
                    } else {
                        rem[q2.peek()] = rem[q2.peek()] - (mat[j][1] - currTime);
                        currTime += (mat[j][1] - currTime);
                        q3.add(q2.poll());                   
                    }
                } else{
                    if(rem[q2.peek()] <= quantumQ2){
                        currTime += rem[q2.peek()];
                        rem[q2.peek()] = -1;
                        completed++;
                        mat[q2.peek()][3] = currTime;
                        q2.poll();
                    } else {
                        rem[q2.peek()] = rem[q2.peek()] - quantumQ2;
                        currTime += quantumQ2;
                        q3.add(q2.poll());                   
                    }
                }
            } else if (q1.peek() == null && q2.peek() == null){
                if(q3.peek() != null){
                    if(j < num && mat[j][1] - currTime >= rem[q3.peek()]){
                        currTime += rem[q3.peek()];
                        rem[q3.peek()] = -1;
                        completed++;
                        mat[q3.peek()][3] = currTime;
                        q3.poll();
                    } else if(j < num && mat[j][1] - currTime < rem[q3.peek()]){
                        rem[q3.peek()] = rem[q3.peek()] - (mat[j][1] - currTime);
                        currTime += mat[j][1] - currTime;  
                    } else{
                        currTime += rem[q3.peek()];
                        rem[q3.peek()] = -1;
                        completed++;
                        mat[q3.peek()][3] = currTime;
                        q3.poll();
                    }
                }
                if(j < num && j - completed < 1 && mat[j][1] > currTime){
                    currTime = mat[j][1];
                }
            }
        }

        turnAroundTime(num, mat);
        waitingTime(num, mat);
        printResult(num, mat);
    }

    public static void turnAroundTime(int num, int[][] mat){
        for(int i = 0; i < num; i++) mat[i][4] = mat[i][3] - mat[i][1];
    }

    public static void waitingTime(int num, int[][] mat){
        for(int i = 0; i < num; i++) mat[i][5] = mat[i][4] - mat[i][2];
    }

    public static double avgTAT(int num, int[][] mat){
        int sum = 0;
        for(int i = 0; i < num; i++) sum += mat[i][4];
        return (double)sum/num;
    }

    public static double avgWT(int num, int[][] mat){
        int sum = 0;
        for(int i = 0; i < num; i++) sum += mat[i][5];
        return (double)sum/num;
    }

    public static void MFQSScheduling(int num, int[][] mat, int quantumQ1, int quantumQ2){
        arrangeArrival(num, mat);
        completionTime(num, mat, quantumQ1, quantumQ2);
    }

    public static void printResult(int num, int mat[][]){
        System.out.println("\t\t\t\t\tmultilevel Feedback Queue Scheduling");
        System.out.println("Process ID \t Arrival Time \t Burst Time \t Completion Time \t Turn Around Time \t Waiting Time");
        for(int i = 0; i < num; i++){
            System.out.println("    " + mat[i][0] + "\t\t\t" + mat[i][1] + "\t    " + mat[i][2] + "\t\t        " + mat[i][3] + "\t\t\t" + mat[i][4] + "\t\t\t" + mat[i][5]);
        }
        System.out.println("Average Turn Around Time : " + avgTAT(num, mat));
        System.out.println("Average Waiting Time : " + avgWT(num, mat));
    }

    public static void main(String[] args){
        System.out.println("**********Multilevel Feedback Queue Scheduling**********");
        System.out.println("Uses Three Queues, Q1 with RR (quantum = quantumQ1), Q2 with RR (quantum = quantumQ2) and Q3 with FCFS)");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of processes : ");
        int n = sc.nextInt();
        System.out.println();
        int[][] mat = new int[n][6];

        System.out.print("Enter 0 to put custom process ID's or -1 to give default 1 to N as process ID's : ");
        int id = sc.nextInt();
        System.out.println();

        if(id == -1){
            for(int i = 0; i < n; i++) mat[i][0] = i + 1;
        } else {
            System.out.println("Enter Process ID's(separated by spaces) : ");
            for(int i = 0; i < n; i++) mat[i][0] = sc.nextInt();
        }

        System.out.print("Enter Arrival Times(separated by spaces) : ");
        for(int i = 0; i < n; i++) mat[i][1] = sc.nextInt();

        System.out.println();

        System.out.print("Enter Burst Times(separated by spaces) : ");
        for(int i = 0; i < n; i++) mat[i][2] = sc.nextInt();

        System.out.println();

        System.out.print("Enter quantum time for Queue1 : ");
        int quantQ1 = sc.nextInt();
        System.out.println();

        System.out.print("Enter quantum time for Queue2 : ");
        int quantQ2 = sc.nextInt();
        System.out.println();

        MFQSScheduling(n, mat, quantQ1, quantQ2);
        
    }
}