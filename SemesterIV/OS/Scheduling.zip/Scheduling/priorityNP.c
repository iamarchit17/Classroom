/*
Name: Archit Agrawal
Student ID: 202051213

The following code is a simulation of the Non-Preemptive Priority Scheduling
Documentation:
The matrix mat stores all the data of the processes in the following code
    At index 0 -> Process ID
    At index 1 -> Arrival Time
    At index 2 -> Burst Time
    At index 3 -> Priority (the lower the number, the higher the priority)
    At index 4 -> finish or completion time
    At index 5 -> turn around time
    At index 6 -> waiting time

*/


#include<stdio.h>

//function to arrange processes by their arrival times
void arrangeArrival(int num, int mat[][7]);
//function to calculate completion time for each process
void completionTime(int num, int mat[][7]);
//function to calculate TAT for each process
void turnAroundTime(int num, int mat[][7]);
//function to calculate WT for each process
void waitingTime(int num, int mat[][7]);
//function to calculate average TAT
double avgTAT(int num, int mat[][7]);
//function to calculate average WT
double avgWT(int num, int mat[][7]);
//scheduling function that the user need to call
void priorityScheduling(int num, int mat[][7]);
//utility function to print the result in formatted way
void printResult(int num, int mat[][7]);

void arrangeArrival(int num, int mat[][7]){
    for (int i = 0; i < num; i++) {
        for (int j = 0; j < num - i - 1; j++) {
            if (mat[j][1] > mat[j + 1][1]) {
                for (int k = 0; k < 4; k++) {
                    
                    int temp = mat[j][k];
                    mat[j][k] = mat[j + 1][k];
                    mat[j + 1][k] = temp;
                }
            }
        }
    }

}

void completionTime(int num, int mat[][7]){
    int arr[num];
    for(int i = 0; i < num; i++) arr[i] = 0;
    int j = 0;
    int currTime = mat[0][1];
    int completed = 0;

    while(completed != num){
        while(j < num && arr[j] != -1 && mat[j][1] <= currTime){
            arr[j] = 1;
            j++;
        }

        //for(int s = 0; s <num; s++) printf("%d, ", arr[s]);
        //printf("currTime : %d, j = %d, completed = %d\n", currTime, j, completed);

        int maxPriorAmongArrived = 0;
        for(int k = 0; k < num; k++){
            if(arr[k] == 1){
                maxPriorAmongArrived = k;
                break;
            }
        }

        for(int k = maxPriorAmongArrived + 1; k < num; k++){
            if(arr[k] == 1 && mat[k][3] < mat[maxPriorAmongArrived][3]){
                maxPriorAmongArrived = k;
            }
        }

        currTime += mat[maxPriorAmongArrived][2];
        mat[maxPriorAmongArrived][4] = currTime;
        completed++;
        arr[maxPriorAmongArrived] = -1;
        
        //for(int s = 0; s <num; s++) printf("%d, ", arr[s]);
        //printf("currTime : %d, j = %d, completed = %d\n", currTime, j, completed);
        if(j < num && j - completed < 1 && mat[j][1] > currTime){
            currTime = mat[j][1];
        }
    
        
    }
    //printf("Completion Time Done");
    turnAroundTime(num, mat);
    //printf("TAT Done");
    waitingTime(num, mat);
    //printf("WT Done");
    printResult(num, mat);
}

void turnAroundTime(int num, int mat[][7]){
    for(int i = 0; i < num; i++) mat[i][5] = mat[i][4] - mat[i][1];
}

void waitingTime(int num, int mat[][7]){
    for(int i = 0; i < num; i++) mat[i][6] = mat[i][5] - mat[i][2];
}

double avgTAT(int num, int mat[][7]){
    int sum = 0;
    for(int i = 0; i < num; i++) sum += mat[i][5];
    return (double)sum/num;
}

double avgWT(int num, int mat[][7]){
    int sum = 0;
    for(int i = 0; i < num; i++) sum += mat[i][6];
    return (double)sum/num;
}

void priorityScheduling(int num, int mat[][7]){
    arrangeArrival(num, mat);
    //arrangePriority(num, mat);
    completionTime(num, mat);
}

void printResult(int num, int mat[][7]){
    printf("\t\t\t\tNon-Preemptive Priority Scheduling\n");
    printf("Process ID \t Arrival Time \t Burst Time \t Priority \t Completion Time \t Turn Around Time \t Waiting Time\n");
    for(int i = 0; i < num; i++){
        printf("    %d\t\t\t%d\t     %d\t\t    %d    \t\t%d\t\t\t%d\t\t     %d\n", mat[i][0], mat[i][1], mat[i][2], mat[i][3], mat[i][4], mat[i][5], mat[i][6]);
    }

    printf("Average Turn Around Time : %f\n", avgTAT(num, mat));
    printf("Average Wait Time : %f\n", avgWT(num, mat));
}

int main(){
    printf("**********Non-Preemptive Priority Scheduling**********\n");
    int n;
    printf("Enter the number of processes : ");
    scanf("%d", &n);
    int mat[n][7];

    printf("Enter 0 to put custom process ID's or -1 to give default 1 to N as process ID's : ");
    int id;
    scanf("%d", &id);

    if(id == -1){
        for(int i = 0; i < n; i++) mat[i][0] = i + 1;
    } else {
        printf("Enter Process ID's(separated by spaces) : ");
        for(int i = 0; i < n; i++){
            int s;
            scanf("%d", &s);
            mat[i][0] = s;
        }
    }

    printf("Enter Arrival Times(separated by spaces) : ");

    for(int i = 0; i < n; i++){
        int s;
        scanf("%d", &s);
        mat[i][1] = s;
    }

    printf("Enter Burst Times(separated by spaces) : ");

    for(int i = 0; i < n; i++){
        int s;
        scanf("%d", &s);
        mat[i][2] = s;
    }

    printf("Enter Priorities(separated by spaces) : ");

    for(int i = 0; i < n; i++){
        int s;
        scanf("%d", &s);
        mat[i][3] = s;
    }
    
    priorityScheduling(n, mat);
}