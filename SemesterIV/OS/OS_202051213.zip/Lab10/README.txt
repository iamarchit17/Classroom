ye code galat hai
bhosdiwale ko submit krna tha
toh galat hi kr diya
qki output par kuch aana chahiye tha
the last property is satisfied