ye code github se chhapa tha
pata nahi kitna sahi hai